from random import randint
T = 1
print(T)
N = 5
print(N)
op = ['PUSH', 'POP', 'REVERSE', 'QUERY']
cnt = 0
for i in range(N):
    o = op[randint(0, len(op)-1)]
    if o == 'PUSH': 
        print(o, randint(0, 1))
        cnt += 1
    else:
        if o == 'POP' and cnt == 0:
            o = 'QUERY'
        if o == 'POP':cnt -= 1
        print(o)