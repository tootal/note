#include <bits/stdc++.h>
using namespace std;
struct : deque<int> {
    bool rev = false;
    void push(int x) { rev ? push_front(x) : push_back(x); }
    void pop() { rev ? pop_front() : pop_back(); }
    int& top() { return rev ? front() : back(); }
    int bottom() { return rev ? back() : front(); }
} st;
void push(int x) {
    if (x == 0) st.push(0);
    else if (st.empty()) st.push(1);
    else if (st.top() == 0) st.push(1);
    else st.top()++;
}
void pop() {
    if (st.top() <= 1) st.pop();
    else st.top()--;
}
int query() {
    if (st.empty()) return -1;
    if (st.size() == 1) return st.front() & 1;
    if (st.bottom() == 0) return 1;
    if (st.size() == 2) return st.bottom() & 1;
    return !(st.bottom() & 1);
}
int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":\n";
        st.clear();
        st.rev = false;
        int n;
        cin >> n;
        while (n--) {
            string op;
            cin >> op;
            if (op == "PUSH") {
                int x;
                cin >> x;
                push(x);
            } else if (op == "POP") pop();
            else if (op == "REVERSE") st.rev = !st.rev;
            else if (op == "QUERY") {
                int q = query();
                if (q == -1) cout << "Invalid.\n";
                else cout << q << '\n';
            }
        }
    }
    return 0;
}