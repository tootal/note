#include <bits/stdc++.h>
using namespace std;
const int N = 2e6 + 5;
int st[N * 2];
bool rev;
int bg, ed;
void emplace(int x) {
    if (rev) st[--bg] = x;
    else st[ed++] = x;
}
void pop() {
    int p = rev ? st[bg++] : st[--ed];
    if (p > 1) emplace(p-1);
}

void push(int x) {
    if (x == 0) emplace(0);
    else {
        // int p = pop();
        // if (p == -1) emplace(x);
        // else {
        //     if (p == 0) emplace(0);
        //     else
        //         emplace(p + 1);
        // }
        
        if(bg == ed) emplace(x);
        else{
            //判断栈顶的元素是0还是多个1
            int p = rev ? st[bg] : st[ed - 1];
            if(p == 0) emplace(1);
            else{
                if(rev) st[bg]++;
                else st[ed - 1]++;
            }
        }
    }
}
int query() {
    if (bg == ed) return -1;
    if (bg + 1 == ed) return st[bg] ? (st[bg] & 1) : (st[bg]);
    if (rev) {
        if (st[ed-1] == 0) return 1;
        int x = !(st[ed-1] & 1);
        return (bg + 2 == ed ? (!x) : x);
    } else {
        if (st[bg] == 0) return 1;
        int x = !(st[bg] & 1);
        return (bg + 2 == ed ? (!x) : x);
    }
}
int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ":\n";
        bg = ed = N;
        rev = false;
        int n;
        cin >> n;
        while (n--) {
            string op;
            int x;
            cin >> op;
            if (op == "PUSH") {
                cin >> x;
                push(x);
            } else if (op == "POP") pop();
            else if (op == "REVERSE") rev = !rev;
            else if (op == "QUERY") {
                int q = query();
                if (q == -1) cout << "Invalid.\n";
                else cout << q << '\n';
            }
        }
    }
}