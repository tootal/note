n = int(input())
s = 1
M = 10**9 + 7
for i in range(2, n):
    s = s * i % M
print(s)
