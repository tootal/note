#pragma comment(linker, "/STACK:1024000000,1024000000") 
#include<bits/stdc++.h>
#define SZ(x) ((int)(x).size())
#define USE_CIN_COUT std::ios::sync_with_stdio(0)

typedef long long ll;
typedef unsigned long long ull;

const int N = 1000005;

struct line {
	int l, r, id;
}p[N];

int main() {
    USE_CIN_COUT;
    int n, m;
    std::cin >> n >> m;
    for(int i = 1; i <= n; ++i) {
    	std::cin >> p[i].l >> p[i].r;
    	p[i].id = i;
    }
    std::sort(p + 1, p + n + 1, [] (line const& a, line const& b) { return a.l < b.l;});
    std::priority_queue<int, std::vector<int>, std::greater<int>> Q;
    static int ans = 0, ans_pos_l = 0, ans_pos_r = 0;
    for(int i = 1; i <= n; i++) {
    	Q.push(p[i].r);
    	while(SZ(Q) > m) Q.pop();
    	if(SZ(Q) == m) {
    		int tmp = Q.top() - p[i].l;
    		if(tmp > ans) {
    			ans = tmp;
    			ans_pos_l = p[i].l;
    			ans_pos_r = Q.top();
    		}
    	}
    }
    std::cout << ans << '\n';
    return 0;
}
