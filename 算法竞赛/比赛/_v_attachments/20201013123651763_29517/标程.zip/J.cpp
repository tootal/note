#pragma comment(linker, "/STACK:1024000000,1024000000") 
#include<bits/stdc++.h>
#define SZ(x) ((int)(x).size())
#define USE_CIN_COUT std::ios::sync_with_stdio(0)

typedef long long ll;
typedef unsigned long long ull;

template <typename T>
void out_(T a, int l, int r) {
	for(int i = l; i <= r; i++) 
		std::cerr << a[i] << ' ';
	std::cerr << '\n';
}

int const N = 1e4 + 5;

char min(char c1, char c2) {
	for(char c = 'a'; c <= 'z'; ++c) {
		if(c != c1 && c != c2)
			return c;
	}
	return 'a';
}

int get(char c1, char c2, char c) {
	if(c == c1 && c != c2) return 1;
	if(c == c2 && c != c1) return -1;
	return 0;
}

int main() {
    USE_CIN_COUT;
    int T; 
    std::cin >> T;
    for(int o = 1; o <= T; ++o) {
    	std::string s1, s2;
    	std::string s1_, s2_;
    	std::cin >> s1_ >> s2_;
    	for(int i = 0, len = SZ(s1_); i < len; ++i) 
    		if(s1_[i] == s2_[i]) 
    			;
    		else {
    			s1.push_back(s1_[i]);
    			s2.push_back(s2_[i]);
    		}
    	int sum = 0;
    	std::string ans;
    	for(int i = 0, n = SZ(s1); i < n; ++i) {
    		int lea = n - i - 1;
    		std::vector<char> tmp;
    		tmp.reserve(3);
    		tmp.push_back(s1[i]);
    		tmp.push_back(s2[i]);
    		tmp.push_back(::min(s1[i], s2[i]));
    		std::sort(tmp.begin(), tmp.end());
    		for(auto ch : tmp) {
    			int now_sel_sum = ::get(s1[i], s2[i], ch) + sum;
    			if(-lea <= now_sel_sum && now_sel_sum <= lea) {
    				ans += ch;
    				sum = now_sel_sum;
    				break;
    			}
    		}
    	}
    	std::string com_ans;
    	for(int i = 0, k = 0, n = SZ(s1_); i < n; ++i) 
    		if(s1_[i] == s2_[i])
    			com_ans.push_back('a');
    		else
    			com_ans.push_back(ans[k++]);
    	std::cout << com_ans << '\n';
    }
    return 0;
}
