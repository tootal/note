/* ***********************************************
Author        :yang12138
Created Time  :2018��10��31�� ������ 16ʱ52��05��
File Name     :solve.cpp
************************************************ */
#include <iostream>
#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <string>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <queue>
#include <set>
#include <map>
using namespace std;
#define mem(a,b) memset(a,b,sizeof(a))
typedef long long ll;
typedef pair<int,int>pii;
#define lson (root<<1)
#define rson (root<<1|1)

const int N=105;

double dp[N][N];

void init(){
	for(int i=1;i<N;i++) dp[0][i]=0,dp[i][0]=1.0;

	for(int i=1;i<N;i++){
		for(int j=1;j<N;j++){
			dp[i][j]=(dp[i-1][j]+dp[i][j-1])/2;
		}
	}
}

void solve(){
	int a,b;
	int n,m,x;
	cin>>a>>b>>n>>m;
	for(int i=1;i<=n;i++) cin>>x;
	for(int i=1;i<=m;i++) cin>>x;
	n=(a+9)/10,m=(b+9)/10;

	printf("%.5f\n",dp[n][m]);
}

int main(){
    
	init();
	int T;
	scanf("%d",&T);
	while(T--) solve();
    return 0;
}