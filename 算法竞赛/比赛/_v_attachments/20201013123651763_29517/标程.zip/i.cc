#include <stdio.h>

#define N 100002

char tbl[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
int inv[256];
char str[(N + 2) / 3 * 4], buf[N];

int main(void) {
  for(int i = 0; i < 64; ++i)
    inv[(int)tbl[i]] = i;
  inv['='] = 0;

  while(scanf("%s", str) != EOF) {
    char *out = buf;
    for(char *p = str; *p; p += 4) {
      int a = inv[(int)p[0]],
          b = inv[(int)p[1]],
          c = inv[(int)p[2]],
          d = inv[(int)p[3]];
      *out++ = (a << 2 | b >> 4) & 0xFF;
      if(p[1] == '=') break;
      *out++ = (b << 4 | c >> 2) & 0xFF;
      if(p[2] == '=') break;
      *out++ = (c << 6 | d) & 0xFF;
    }
    *out = '\0';
    puts(buf);
  }

  return 0;
}
