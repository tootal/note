/* ***********************************************
Author        :yang12138
Created Time  :2018��10��31�� ������ 13ʱ32��14��
File Name     :solve.cpp
************************************************ */
#include <iostream>
#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <string>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <queue>
#include <set>
#include <map>
using namespace std;
#define mem(a,b) memset(a,b,sizeof(a))
typedef long long ll;
typedef pair<int,int>pii;
#define lson (root<<1)
#define rson (root<<1|1)

const int N=1e5+10;
int a[N];

int sqr(int x){
	int ans=(int)sqrt(x);
	while((ans+1)*(ans+1)<=x) ans++;
	while(ans*ans>x) ans--;
	return ans;
}

void solve(){
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>a[i];
	int ans=0;
	for(int i=1;i<=m;i++){
		if(i>10) cout<<n<<endl;
		else{
			ans=0;
			for(int j=1;j<=n;j++){
				ans+=a[j];
				a[j]=sqr(a[j]);
			}
			cout<<ans<<endl;
		}
	}
}

int main(){
    
	solve();
    return 0;
}