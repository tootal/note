#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int Maxn=10010;
int n,k;
int num[Maxn];
int main()
{
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&num[i]);
	sort(num+1,num+n+1);
	for (int k=1;k<=(n+1)/2;k++)
	{
		int a=num[k],b=num[n-k+1];
		int number=b-a;
		bool bj=true;
		for (int i=2;i<=sqrt(number);i++)
		{
			if (number%i==0)
			{
				bj=false;
				break;
			}
		}
		if (bj) {printf("%d\n",k);return 0;}
	}
	printf("GG\n");
	return 0;
}
