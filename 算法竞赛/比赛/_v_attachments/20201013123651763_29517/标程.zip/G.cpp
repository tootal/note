/* ***********************************************
Author        :yang12138
Created Time  :2018��10��31�� ������ 14ʱ16��04��
File Name     :solve.cpp
************************************************ */
#include <iostream>
#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <string>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <queue>
#include <set>
#include <map>
using namespace std;
#define mem(a,b) memset(a,b,sizeof(a))
typedef long long ll;
typedef pair<int,int>pii;
#define lson (root<<1)
#define rson (root<<1|1)

const int N=33;
int C[N][N];

void init(){
	C[0][0]=1;
	for(int i=1;i<N;i++){
		C[i][0]=C[i][i]=1;
		for(int j=1;j<i;j++) C[i][j]=C[i-1][j-1]+C[i-1][j];
	}
}

void solve(){
	int n,m;
	cin>>n>>m;
	int ans=(1<<n);
	for(int i=0;i<m;i++) ans-=C[n][i];
	cout<<ans<<endl;
}

int main(){
 //   freopen("1.in","r",stdin);
  //  freopen("1.out","w",stdout);
    
	init();
	int T;
	cin>>T;
	while(T--) solve();

    return 0;
}