#pragma comment(linker, "/STACK:1024000000,1024000000") 
#include<bits/stdc++.h>
#define SZ(x) ((int)(x).size())
#define USE_CIN_COUT std::cin.sync_with_stdio(0), std::cout.sync_with_stdio(0), std::cerr.sync_with_stdio(0)

typedef long long ll;
typedef unsigned long long ull;

int const N = 50005;

struct edge {
	int y, next;
}e[N << 1];
int last[N], ne = 0;
ll pri[100];
ll a[N];
int n, m;
ll ans;

ll bit3[N];

void addedge(int x, int y) {
	e[++ne].y = y;
	e[ne].next = last[x];
	last[x] = ne;
}
void addedge2(int x, int y) {
	::addedge(x, y);
	::addedge(y, x);
}

////////////////////////////
bool vis[N];
std::map<ll, int> M;

ll add(ll x, ll y) {
	ll ret = 0;
	for(int i = 0; i < m; ++i) 
		ret += (x / bit3[i] % 3 + y / bit3[i] % 3) % 3 * bit3[i];
	return ret;
}

ll Cst(ll x) {
	ll ret = 0;
	for(int i = 0; i < m; ++i) 
		ret += (3 - x / bit3[i] % 3) % 3 * bit3[i];
	return ret;
}

int q[N << 1];
int getCenter(int x) {
	static int pre[N];
	static int siz[N];
	int head = 0, tail = 0;
	pre[x] = 0;
	q[++tail] = x;
	while(head < tail) {
		int now = q[++head];
		for(int i = last[now]; i != 0; i = e[i].next) {
			int y = e[i].y;
			if(y == pre[now] || vis[y]) continue;
			pre[y] = now;
			q[++tail] = y;
		}
	}
	int root = x, mx_sz = tail, _sz = tail;
	for(int o = head; o >= 1; --o) {
		int now = q[o];
		siz[now] = 1;
		int cnt = 0;
		for(int i = last[now]; i != 0; i = e[i].next) {
			int y = e[i].y;
			if(y == pre[now] || vis[y]) continue;
			siz[now] += siz[y];
			if(cnt < siz[y]) cnt = siz[y];
		}
		cnt = std::max(cnt, _sz - siz[now]);
		if(cnt < mx_sz) {
			mx_sz = cnt;
			root = now;
		}
	}
	return root;
}

ll vec[N];
int cnt_vec = 0;
void bfs(int x, ll _st) {
	static int pre[N];
	static ll st[N];
	cnt_vec = 0;
	int head = 0, tail = 1;
	q[1] = x;
	pre[x] = 0;
	st[x] = _st;
	while(head < tail) {
		int now = q[++head];
		vec[++cnt_vec] = st[now];
		for(int i = last[now]; i != 0; i = e[i].next) if(vis[e[i].y] == 0 && pre[now] != e[i].y) {
			pre[e[i].y] = now;
			st[e[i].y] = ::add(st[now], a[e[i].y]);
			q[++tail] = e[i].y;
		}
	}
}

void getans(int u) {
	u = ::getCenter(u);
	vis[u] = 1;
	if(a[u] == 0) ++ans;
	M.clear();
	for(int i = last[u]; i != 0; i = e[i].next) {
		if(vis[e[i].y]) continue;
		int v = e[i].y;
		::bfs(v, a[v]);
		for(int j = 1; j <= cnt_vec; ++j) if(M.count(vec[j])) 
			ans += M[vec[j]];
		for(int j = 1; j <= cnt_vec; ++j) {
			ll now = ::add(vec[j], a[u]);
			ll Cnow = ::Cst(now);
			if(now == 0) ++ans;
			if(M.count(Cnow)) M[Cnow]++;
			else M[Cnow] = 1;
		}
	}
	for(int i = last[u]; i != 0; i = e[i].next) if(vis[e[i].y] == 0) 
		::getans(e[i].y);
}

int main() {
	bit3[0] = 1;
	for(int i = 1; i <= 31; ++i) bit3[i] = bit3[i - 1] * 3;
    USE_CIN_COUT;
    while(std::cin >> n) {
    	ne = 0;
    	for(int i = 1; i <= n; ++i) {
    		last[i] = vis[i] = 0;
    		a[i] = 0;
    	}

    	std::cin >> m;
    	for(int i = 0; i < m; ++i) 
    		std::cin >> pri[i];
    	for(int i = 1; i <= n; ++i) {
    		ll val; 
    		std::cin >> val;
    		for(int j = 0; j < m; ++j) {
    			int cnt = 0;
    			while(val % pri[j] == 0) {
    				val /= pri[j];
    				cnt++;
    			}
    			cnt %= 3;
    			a[i] += cnt * bit3[j];
    		}
    	}

    	for(int i = 1; i < n; ++i) {
    		int x, y;
    		std::cin >> x >> y;
    		::addedge2(x, y);
    	}

    	ans = 0;
    	::getans(1);
    	std::cout << ans << '\n';
    }
    return 0;
}

/*
10
2 2 3
8 1 9 1 4 6 6 2
2 9
1 2
1 3
2 4
2 5
2 6
3 7
3 8
5 9
5 10
*/
