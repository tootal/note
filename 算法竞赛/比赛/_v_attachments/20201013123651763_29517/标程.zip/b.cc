#include <iostream>

using namespace std;

int main()
{
	int t = 0;
	cin >> t;
	while (t--)
	{
		int n = 0, k = 0;
		cin >> n >> k;
		static int a[1005];
		for (int i = 0; i < n; i++)
			cin >> a[i];
		for (int d = 1; ; d++)
		{
			int count = 0;
			for (int i = 0; i < n; i++)
			{
				if (d % a[i] == 0)
					count++;
			}
			if (count >= k)
			{
				cout << d << endl;
				break;
			}
		}
	}
	return 0;
}
