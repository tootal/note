#include <iostream>

using namespace std;

int main()
{
	int t = 0;
	cin >> t;
	while (t--)
	{
		int a = 0, b = 0;
		cin >> a >> b;
		cout << a * b % 10017 << endl;
	}
	return 0;
}
