#include <iostream>

using namespace std;

int main()
{
	int t = 0;
	cin >> t;
	while (t--)
	{
		int n = 0;
		cin >> n;
		while (n--)
			cout << "\"LJJnb!!!!!!!''" << endl;
		cout << endl;
	}
	return 0;
}
