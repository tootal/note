/* ***********************************************
Author        :yang12138
Created Time  :2018��10��31�� ������ 12ʱ43��05��
File Name     :solve.cpp
************************************************ */
#include <iostream>
#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <string>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <queue>
#include <set>
#include <map>
using namespace std;
#define mem(a,b) memset(a,b,sizeof(a))
typedef long long ll;
typedef pair<int,int>pii;
#define lson (root<<1)
#define rson (root<<1|1)

void solve(){
	int n;
	cin>>n;
	int ans=0;
	while(n>1){
		ans++,n/=2;
	}
	cout<<ans<<endl;
}

int main(){
    
	int T;
	cin>>T;
	while(T--) solve();
    return 0;
}